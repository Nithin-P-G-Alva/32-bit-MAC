# 32-bit-MAC
32-bit MAC Unit with Vedic Multiplier and Carry Save Adder Design and  comparative Analysis
